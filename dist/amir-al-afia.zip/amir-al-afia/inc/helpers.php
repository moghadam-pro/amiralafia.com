<?php
/**
 * Small shared helpers.
 *
 * @package AmirAlAfia
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print one of the theme's inline SVG partials (logo, logo mark).
 * These are static files we authored, so the markup is trusted.
 */
function aaa_inline_svg( string $name ): void {
	$path = AAA_DIR . '/inc/' . $name . '-inline.svg';
	if ( ! is_readable( $path ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.EscapeOutput -- static, theme-authored SVG.
	echo file_get_contents( $path );
}

/**
 * The site logo: a Customizer custom logo when set, otherwise the brand SVG.
 */
function aaa_brand_logo(): void {
	if ( has_custom_logo() ) {
		$id  = (int) get_theme_mod( 'custom_logo' );
		$img = wp_get_attachment_image( $id, 'full', false, array(
			'class' => 'brand-logo',
			'alt'   => get_bloginfo( 'name', 'display' ),
		) );
		if ( $img ) {
			echo $img; // phpcs:ignore WordPress.Security.EscapeOutput -- wp_get_attachment_image escapes.
			return;
		}
	}
	aaa_inline_svg( 'logo' );
}

/**
 * Digits only, for tel: and wa.me / t.me links.
 */
function aaa_digits( string $value ): string {
	return preg_replace( '/\D+/', '', $value );
}

/**
 * A WhatsApp deep link for a phone number in any human format.
 */
function aaa_whatsapp_url( string $phone ): string {
	return 'https://wa.me/' . aaa_digits( $phone );
}

/**
 * Build an Instagram profile URL from a handle.
 *
 * Accepts a handle with or without the leading @, or a full URL pasted
 * straight out of the address bar.
 *
 * @param string $handle Instagram username or profile URL.
 */
function aaa_instagram_url( string $handle ): string {
	$handle = ltrim( trim( $handle ), '@' );
	if ( '' === $handle ) {
		return '';
	}
	if ( str_starts_with( $handle, 'http' ) ) {
		return esc_url_raw( $handle );
	}
	return 'https://www.instagram.com/' . rawurlencode( $handle ) . '/';
}

/**
 * A Telegram link. Accepts either a @handle or a bare username.
 */
function aaa_telegram_url( string $handle ): string {
	$handle = ltrim( trim( $handle ), '@' );
	if ( '' === $handle ) {
		return '';
	}
	if ( str_starts_with( $handle, 'http' ) ) {
		return esc_url_raw( $handle );
	}
	return 'https://t.me/' . rawurlencode( $handle );
}

/**
 * Format a price the way the design shows it: a currency symbol and thousands
 * separators, no decimals. Falls back to the raw string for "On request" etc.
 */
function aaa_format_price( $price, string $currency = '' ): string {
	$currency = $currency ?: (string) get_theme_mod( 'aaa_currency', '$' );
	if ( '' === (string) $price ) {
		return __( 'Price on request', 'amir-al-afia' );
	}
	if ( ! is_numeric( $price ) ) {
		return (string) $price;
	}
	return $currency . number_format_i18n( (float) $price, 0 );
}

/**
 * Print the attributes for a scroll-reveal element:
 * `class="sr …" data-delay="80"`.
 *
 * @param int    $delay Reveal delay in milliseconds.
 * @param string $extra Additional classes.
 */
function aaa_sr( int $delay = 0, string $extra = '' ): void {
	printf(
		'class="%s" data-delay="%d"',
		esc_attr( trim( 'sr ' . $extra ) ),
		$delay
	);
}

/**
 * A placeholder image URL for property cards with no featured image set.
 */
function aaa_placeholder_image(): string {
	return AAA_URI . '/assets/img/placeholder.svg';
}

/**
 * A photo credit line for an attachment, or '' when none is recorded.
 *
 * The starter-content importer stores the photographer, the licence and the
 * source page on each image it brings in. Creative Commons BY and BY-SA both
 * require that credit to be shown wherever the photo is; CC0 and public-domain
 * images carry it too, because knowing where a photo came from is useful even
 * when it is not legally required.
 *
 * @param int $attachment_id Attachment to describe.
 */
function aaa_media_credit( int $attachment_id ): string {
	$author  = (string) get_post_meta( $attachment_id, '_aaa_credit_author', true );
	$license = (string) get_post_meta( $attachment_id, '_aaa_credit_license', true );
	$source  = (string) get_post_meta( $attachment_id, '_aaa_credit_source', true );

	if ( '' === $author && '' === $license ) {
		return '';
	}

	$name = $author ?: __( 'Unknown', 'amir-al-afia' );
	if ( $source ) {
		$name = sprintf(
			'<a href="%s" target="_blank" rel="noopener nofollow">%s</a>',
			esc_url( $source ),
			esc_html( $name )
		);
	} else {
		$name = esc_html( $name );
	}

	if ( '' === $license ) {
		/* translators: %s: photographer name, possibly linked. */
		return sprintf( __( 'Photo: %s', 'amir-al-afia' ), $name );
	}

	return sprintf(
		/* translators: 1: photographer name, possibly linked. 2: licence name. */
		__( 'Photo: %1$s (%2$s)', 'amir-al-afia' ),
		$name,
		esc_html( $license )
	);
}

/**
 * The hero's three scrolling columns.
 *
 * Eighteen Customizer slots, six per column, so a slot maps to a place on
 * screen the office can point at: images 1-6 are the left column, 7-12 the
 * middle, 13-18 the right.
 *
 * Six is not arbitrary. Each column renders its list twice so the loop has a
 * copy to land on, and a tile is about 270px tall at the width these columns
 * get. Six tiles is roughly 1,620px of track, which is taller than the hero on
 * any screen it will meet - so the second copy is always off-screen and the
 * same photograph is never visible in two places at once. Fewer than six and
 * the repeat becomes obvious on a tall display.
 *
 * The durations are unequal and not multiples of one another, and each column
 * starts part-way through its own cycle via a negative delay, so the three
 * never line up. The middle column is reversed in CSS.
 *
 * @return array<int, array<string, mixed>>
 */
function aaa_hero_columns(): array {
	$per_column = 6;

	// Roughly 5-7px a second: slow enough to read as ambient drift rather than
	// motion. Kept non-harmonic so the three columns never fall into step.
	$columns = array(
		array( 'duration' => '220s', 'offset' => '0s' ),
		array( 'duration' => '265s', 'offset' => '-97s' ),
		array( 'duration' => '310s', 'offset' => '-211s' ),
	);

	$any = false;

	foreach ( $columns as $index => $column ) {
		$images = array();

		for ( $slot = 1; $slot <= $per_column; $slot++ ) {
			$id = (int) get_theme_mod( 'aaa_collage_' . ( $index * $per_column + $slot ), 0 );
			if ( $id ) {
				$any = true;
				$images[] = $id;
			}
		}

		$columns[ $index ]['images'] = $images;
	}

	// Drop any column left empty rather than render a stack of placeholders.
	$columns = array_values(
		array_filter(
			$columns,
			static fn( array $column ): bool => ! empty( $column['images'] )
		)
	);

	return $any ? $columns : array();
}
